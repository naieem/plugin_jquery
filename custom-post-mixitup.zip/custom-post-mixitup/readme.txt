=== Custom post mixItup ===

Contributors: nsstheme
Tags: portfolio, product item, image gallery, video gallery, audio gallery, mixItup etc;  
Requires at least: 1.1
Tested up to: 1.1
Stable tag: 1.1
License: GPLv2 or later

Custom post mixItup show your profile or image gallery 

== Description ==

custom post mixItup, if you use it. you can easily create a custom post, taxonomics and put your required title content and images. If you show your desire data as a filter system. 

major features in Custom post mixItup:

* Automatically create a custom post and taxonomic.
* Easy edit your title and contents and images.
* unlimited image and contents created if you want.
* and finally view a nice modern design..
* It's totally bug free and check to wp debug true. 

== Installation ==

*. upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the wordpress plugins screen directly.
*. activate the plugin through the 'Plugins' screen in wordPress
*. use the Settings->plugin Name screen to configure the plugin

Upload the Custom post mixItup plugin to your page or create a blank templete in you theme: link this <?php */template name: 'my template'/* echo do_shortcode("[showing_mixup]"); ?>

1.1: You're done!

== Screenshots ==

1. assets/screenshot-1.png This is the new custom post page. If you create more than page please insert your title, content, image and create new category.
2. assets/screenshot-2.png This is the second screen shot which is used to category and if you went to edit,update and delete for this purpose. 
3. assets/screenshot-3.png This is a short code which is used/show the page content.So it's past to your page ro create a new blank template. 
 
== Changelog ==
= 1.1 =
*Release Date - 24 August 2016*
